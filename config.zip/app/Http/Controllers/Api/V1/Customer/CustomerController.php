<?php

namespace App\Http\Controllers\Api\V1\Customer;

use App\Helpers\ApiResponseHelper;
use App\Http\Controllers\Controller;
use App\Http\Requests\CustomerProfileRequest;
use App\Http\Resources\CustomerProfileResponse;


class CustomerController extends Controller
{
    //

}

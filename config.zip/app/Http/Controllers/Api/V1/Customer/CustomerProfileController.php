<?php

namespace App\Http\Controllers\Api\V1\Customer;

use App\Helpers\ApiResponseHelper;
use App\Helpers\ImageUploadHelper;
use App\Http\Controllers\Controller;
use App\Http\Requests\CustomerProfileRequest;
use App\Http\Requests\CustomerProfileUpdateRequest;
use App\Http\Resources\CustomerProfileResponse;
use Nette\Utils\Image;

class CustomerProfileController extends Controller
{
    //

    public function getProfile(CustomerProfileRequest $request)
    {
        $user = $request->user();

        return ApiResponseHelper::success(new CustomerProfileResponse($user),"Profile fetched successfully",200);


    }

    public function updateProfile(CustomerProfileUpdateRequest $request)
    {
        $user = $request->user();

        if ($request->all()==[]) {
            return ApiResponseHelper::error("No data provided for update",400);
        }



        // UPDATE NAME
        if ($request->filled('name')) {
            $user->name = $request->name;
        }

        // UPDATE PHONE
        if ($request->filled('phone')) {
            $user->number = $request->phone;
        }

        // IMAGE UPLOAD
        if ($request->hasFile('image')) {
            $user->image = ImageUploadHelper::upload(
                $request->file('image'),  // UploadedFile
                'assets/images/customers',        // Folder
                'customer_'.$user->id,     // Old image to delete
                75,                       // Quality
                500,                      // Max width
                500                       // Max height
            );
        }

        $user->save();



        return ApiResponseHelper::success(new CustomerProfileResponse($user),"Profile updated successfully",200);

    }
}
